// components/SplashScreen.js
import React from 'react';

const SplashScreen = () => {
  return (
    <div className="splashScreen">
        <div className="loadingLogo"><img src="/images/Anytru.png" /></div>
    </div>
  );
};

export default SplashScreen;
