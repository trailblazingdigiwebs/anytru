import React from "react";

const Logo = () => {
  return (
    <>
      <div>
        <a href="/homepage">
          <img className="logoHeader" src="/images/logo.png" alt="AnyTru" />
        </a>
      </div>
    </>
  );
};

export default Logo;