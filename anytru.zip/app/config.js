// config.js
const config = {
    apiBaseUrl: 'https://anytru.ap-south-1.elasticbeanstalk.com',
    domainUrl: 'https://anytru.com',

    // apiBaseUrl: 'http://localhost:5000',
    // domainUrl: 'http://localhost:3000',

    // apiBaseUrl: 'http://10.5.49.96:5000',
    // domainUrl: 'http://10.5.49.96:3000',
    
  };
  
  export default config;
  
  